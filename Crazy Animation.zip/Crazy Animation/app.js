let $=jQuery;

$(function () {

    // Sometimes we force no-js mode for fallback version
	if ($('html').hasClass('no-js')) return;

    NoJsMode = function(){
        var obj = this;
        var dir = 'down';

        $('html').removeClass('js').addClass('no-js no-js-mode');

        $('.section').each(function(){ 
            $(this).on('click', function(){
                var y = $(this).offset().top;
                $('html, body').stop().animate({ 'scrollTop': y}, 600, 'swing');
            });
        });
    };

    SectionNav = function (el) {
        var obj = this;
        obj.el = $(el);

        this.prevCurr = 1;   // use this to calculate distance between sections when switching
		this.active = [];

        this.init = function(){
            obj.onResize(null);
            $(window).on('scroll', obj.snapPointListener);
            $('li', obj.el).on('click', obj.onNavClick);
        };

        this.onResize = function(wh){
            var ul = obj.el.find('ul');
			var offset = (wh - ul.height() ) / 2;
			ul.css('top', offset);
        };

        this.onNavClick = function(e, n, speed){
            var n = n || $(e.target).closest('li').index()+1; 
            if (e)  e.preventDefault();

            if (Math.abs(obj.prevCurr - n)==1) obj.switchSection(n);
            obj.changePageTransition(n, speed);
        };

        this.snapPointListener = function(){
            var yPos = $(window).scrollTop();
			var n = Math.floor(yPos / app.PAGEHEIGHT);
            if (n == app.currPage) return;

            obj.switchSection(n);
        };

        this.switchSection = function(n){
            obj.prevCurr = app.currPage;
            app.currPage = n;
			obj.setActiveNavItem(n);
            obj.setActiveSection(n);
		};
        this.goPrevious = function(){
			if (app.currPage == 1) return;
			app.currPage--;
			obj.onNavClick(null, app.currPage);
		};
		this.goNext = function(){     
			if (app.currPage == app.numberOfSections) return;
			app.currPage++;
			obj.onNavClick(null, app.currPage);
		};

        this.setActiveSection = function(n){
            if (Math.abs(obj.prevCurr - n)>1) return;

            app.aSections.eq(n).addClass('adjacent').removeClass('active');  
			if (n-2 >= 0) app.aSections.eq(n-2).addClass('adjacent').removeClass('active');
			if (n-1 >= 0) app.aSections.eq(n-1).addClass('active').removeClass('adjacent');
			app.aSections.filter(':gt('+(n)+')').removeClass(' active adjacent');
        };

        this.setActiveNavItem = function(n){
            $('li', obj.el).removeClass('current').eq(n-1).addClass('current');
        };

        this.changePageTransition = function(n, sp){
            var yPos = app.getScrollPosFromCurrent(n),
                dirDown = (n > app.currPage) ? true : false,
                distance = Math.abs(obj.prevCurr - n),
                speed = (distance/4) * 2000,
				sectionEase = (distance < 4) ? 'linear' : 'swing';

            speed = (speed < 400) ? 400 : speed;    // min speed 
            if (sp) speed = sp;
            $('html, body').stop().animate({ 'scrollTop': yPos}, speed, sectionEase);
        };
        this.init();
    }

    app = {
        PAGEHEIGHT: 1000,
        NOJSMODE: false,

        numberOfSections: 0,
        currPage: 0,
        mainContainer: $('#mainContainer'),
        aSections: new Array(),
        sectionsNav: [],

        sectionsWrapper: $('#sections-wrapper'),
        prevScroll: -100,

        init: function () {

            app.aSections = $('.section', app.sectionsWrapper);
            app.numberOfSections = app.aSections.length;

            // DESKTOP Skrollr version
            skrollr.init({
                forceHeight: false,
                render: function(){
                    // do something?
                }
            });

            // Change the body height depends on elements in the page
            var bodyHeight = (app.numberOfSections * app.PAGEHEIGHT) + (app.PAGEHEIGHT*2); // front page + hidden page
            $('body').height(bodyHeight);

            // Instantiate sectionsNav
            app.sectionsNav = new SectionNav('#sections-nav');

            $('#intro-page').find('a, .front-car').on('click', function(){ 
                app.sectionsNav.onNavClick(null, 1, 1600);
                return false; 
            });

            // Change the height when the page resizing
            $(document).on('keydown', app.onKeypress);
            $(window)
                .on('scroll', app.onScroll)
                .on('resize', app.onResize);
            app.onResize();

        },
        onScroll: function () {
            var yPos = $(window).scrollTop();
            if (app.prevScroll < 0) {
                setTimeout(function(){ $(window).scrollTop(1); }, 600);
            }
            app.prevScroll = yPos;
        },
        onResize: function () {
            app.mainContainer.height($(window).height());

            // aspect ratio?
            var ww = $(window).width();
            var wh = $(window).height();
            var isLandscape = (ww > wh);

            // sections layer - force square using longest side
            var sq = (isLandscape) ? Math.ceil(ww * 1.5) : Math.ceil(wh * 1.5);
            var leftOffset = Math.ceil(((sq - ww ) / 2)*-1);
            var topOffset = Math.ceil(((sq - wh ) / 2)*-1);
            app.sectionsWrapper.width(sq).height(sq).css({
                'left': leftOffset,
                'top': topOffset
            });

            app.sectionsNav.onResize(wh);
        },
        onKeypress: function(e){
            if ($('.embed.open').length) return;
            switch(e.keyCode){
                case 37:    app.sectionsNav.goPrevious(); break;
                case 39:    app.sectionsNav.goNext(); break;
                default:
            }
        },
        getScrollPosFromCurrent: function(n){
            return ((n-1) * app.PAGEHEIGHT) + app.PAGEHEIGHT;
        },
        getCurrentFromScrollPos: function(){
            return Math.floor($(window).scrollTop() / 1000);
        },
        isLandscape: function(){
            var ww = $(window).width();
            var wh = $(window).height();
            return (ww > wh);
        }
    };

    app.init();
});